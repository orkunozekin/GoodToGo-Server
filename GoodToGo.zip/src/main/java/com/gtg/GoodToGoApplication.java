package com.gtg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoodToGoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoodToGoApplication.class, args);
	}

}
